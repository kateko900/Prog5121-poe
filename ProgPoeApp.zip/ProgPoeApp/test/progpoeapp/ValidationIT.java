/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package progpoeapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author MP
 */
public class ValidationIT {
    
    public ValidationIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of isValidUsername method, of class Validation.
     */
    @Test
    public void testIsValidUsername() {
        System.out.println("isValidUsername");
        String username = "";
        boolean expResult = false;
        boolean result = Validation.isValidUsername(username);
        assertEquals(expResult, result);

    }

    /**
     * Test of isValidPhone method, of class Validation.
     */
    @Test
    public void testIsValidPhone() {
        System.out.println("isValidPhone");
        String phone = "";
        boolean expResult = false;
        boolean result = Validation.isValidPhone(phone);
        assertEquals(expResult, result);
       
    }

    /**
     * Test of isValidPassword method, of class Validation.
     */
    @Test
    public void testIsValidPassword() {
        System.out.println("isValidPassword");
        String password = "";
        boolean expResult = false;
        boolean result = Validation.isValidPassword(password);
        assertEquals(expResult, result);
  
    }

    /**
     * Test of registerUser method, of class Validation.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String username = "";
        String phone = "";
        String password = "";
        boolean expResult = false;
        boolean result = Validation.registerUser(username, phone, password);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of loginUser method, of class Validation.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String username = "";
        String password = "";
        boolean expResult = false;
        boolean result = Validation.loginUser(username, password);
        assertEquals(expResult, result);
       
    }
    
}
