/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progpoeapp;

import java.util.HashMap;

public class Validation {
    public static HashMap<String, String> users = new HashMap<>();
    public static HashMap<String, String> phones = new HashMap<>();

    public static boolean isValidUsername(String username) {
        return username != null && !username.isEmpty() && username.length() <= 5 && !users.containsKey(username);
    }

    public static boolean isValidPhone(String phone) {
        if (phone == null || !phone.startsWith("+27")) return false;
        String digits = phone.substring(3);
        return digits.length() == 9 && digits.matches("\\d+");
    }

    public static boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;
        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) hasUpper = true;
            else if (Character.isLowerCase(ch)) hasLower = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else hasSpecial = true;
        }
        return hasUpper && hasLower && hasDigit && hasSpecial;
    }

    public static boolean registerUser(String username, String phone, String password) {
        if (isValidUsername(username) && isValidPhone(phone) && isValidPassword(password)) {
            users.put(username, password);
            phones.put(username, phone);
            return true;
        }
        return false;
    }

    public static boolean loginUser(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }
}
