/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progpoeapp;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.HashMap;

public class ProgPoeApp {
    // Store users
    public static HashMap<String, String> users = new HashMap<>();
    public static HashMap<String, String> phones = new HashMap<>();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegistrationForm());
    }
}

// ---------------- Registration Form ----------------
class RegistrationForm extends JFrame {
    private JTextField usernameField, phoneField;
    private JPasswordField passwordField;
    private JButton registerButton, goToLoginButton;

    public RegistrationForm() {
        setTitle("Registration");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Background panel with pink color and black border
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBackground(Color.PINK);
        panel.setBorder(new LineBorder(Color.BLACK, 3));

        JLabel usernameLabel = createStyledLabel("Username (max 5 chars):");
        usernameField = new JTextField();

        JLabel phoneLabel = createStyledLabel("Phone (+27xxxxxxxxx):");
        phoneField = new JTextField();

        JLabel passwordLabel = createStyledLabel("Password:");
        passwordField = new JPasswordField();

        registerButton = new JButton("Register");
        goToLoginButton = new JButton("Go to Login");

        // Square style
        setSquareStyle(usernameField);
        setSquareStyle(phoneField);
        setSquareStyle(passwordField);
        setSquareStyle(registerButton);
        setSquareStyle(goToLoginButton);

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(phoneLabel);
        panel.add(phoneField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(registerButton);
        panel.add(goToLoginButton);

        add(panel);

        registerButton.addActionListener(e -> registerUser());
        goToLoginButton.addActionListener(e -> {
            dispose();
            new LoginForm();
        });

        setVisible(true);
    }

    private void registerUser() {
        String username = usernameField.getText().trim();
        String phone = phoneField.getText().trim();
        String password = new String(passwordField.getPassword());

        StringBuilder errors = new StringBuilder();

        // Username validation
        if (username.isEmpty() || username.length() > 5) {
            errors.append("❌ Username must not be longer than 5 characters.\n");
        } else if (ProgPoeApp.users.containsKey(username)) {
            errors.append("❌ Username already exists.\n");
        }

        // Phone validation
        if (!phone.startsWith("+27")) {
            errors.append("❌ Phone number must start with +27.\n");
        } else {
            String digitsOnly = phone.substring(3);
            if (digitsOnly.length() != 9 || !digitsOnly.matches("\\d+")) {
                errors.append("❌ Phone number must be exactly 9 digits after +27.\n");
            }
        }

        // Password validation
        if (!isValidPassword(password)) {
            errors.append("❌ Password must be at least 8 chars, include uppercase, lowercase, number, and special char.\n");
        }

        // Show all errors if any
        if (errors.length() > 0) {
            JOptionPane.showMessageDialog(this, errors.toString(), "Validation Errors", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Save user if no errors
        ProgPoeApp.users.put(username, password);
        ProgPoeApp.phones.put(username, phone);

        JOptionPane.showMessageDialog(this, "✅ Registration successful! Please login.");
        dispose();
        new LoginForm();
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 8) return false;
        boolean hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;
        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) hasUpper = true;
            else if (Character.isLowerCase(ch)) hasLower = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else hasSpecial = true;
        }
        return hasUpper && hasLower && hasDigit && hasSpecial;
    }

    // Utility: force square style
    private void setSquareStyle(JComponent comp) {
        comp.setBorder(new LineBorder(Color.BLACK, 2, false)); // squared
        comp.setBackground(Color.WHITE);
        comp.setFont(new Font("Arial", Font.PLAIN, 14));
    }

    // Utility: styled label (bold black)
    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(Color.BLACK);
        return label;
    }
}

// ---------------- Login Form ----------------
class LoginForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginForm() {
        setTitle("Login");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBackground(Color.PINK);
        panel.setBorder(new LineBorder(Color.BLACK, 3));

        JLabel usernameLabel = createStyledLabel("Username:");
        usernameField = new JTextField();

        JLabel passwordLabel = createStyledLabel("Password:");
        passwordField = new JPasswordField();

        loginButton = new JButton("Login");

        setSquareStyle(usernameField);
        setSquareStyle(passwordField);
        setSquareStyle(loginButton);

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(new JLabel());
        panel.add(loginButton);

        add(panel);

        loginButton.addActionListener(e -> loginUser());

        setVisible(true);
    }

    private void loginUser() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (ProgPoeApp.users.containsKey(username) && ProgPoeApp.users.get(username).equals(password)) {
            JOptionPane.showMessageDialog(this,
                    "✅ Welcome, " + username + "!\n📱 Phone: " + ProgPoeApp.phones.get(username));
        } else {
            JOptionPane.showMessageDialog(this, "❌ Invalid username or password.");
        }
    }

    private void setSquareStyle(JComponent comp) {
        comp.setBorder(new LineBorder(Color.BLACK, 2, false));
        comp.setBackground(Color.WHITE);
        comp.setFont(new Font("Arial", Font.PLAIN, 14));
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(Color.BLACK);
        return label;
    }
}
